<?php

namespace App\Controller;

use App\Entity\Announcement; // Modèle d'annonce
use Doctrine\ORM\EntityManagerInterface; // Ajouter cette ligne pour l'EntityManager
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class ApiController extends AbstractController
{
    private $entityManager;

    // Injecte l'EntityManagerInterface dans le constructeur
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/api/hello', name: 'api_hello', methods: ['GET'])]
    public function hello(): Response
    {
        // Utilise l'EntityManager pour obtenir le repository de Announcement
        $announcements = $this->entityManager->getRepository(Announcement::class)->findAll();

        return $this->render('hello.html.twig', [
            'announcements' => $announcements,
        ]);
    }

    #[Route('/add-announcement', name: 'add_announcement', methods: ['POST'])]
    public function addAnnouncement(Request $request): Response
    {
        $announcement = new Announcement();
        
        // Récupérer les données du formulaire
        $announcement->setTitle($request->request->get('title'));
        $announcement->setContent($request->request->get('content'));
        
        // Enregistrer dans la base de données
        $this->entityManager->persist($announcement);
        $this->entityManager->flush();
        
        // Rediriger vers la page Hello
        return $this->redirectToRoute('api_hello');
    }
}
